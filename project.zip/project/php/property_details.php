<?php

// Establish a connection to the PostgreSQL database
$connection = pg_connect("host='localhost' dbname='info 2413' user='postgres' password='Kirpa.2003'");

if (!$connection) {
    echo "Failed to connect to PostgreSQL database";
    exit;
}

// Query to fetch data from the 'property' table
$query = "SELECT * FROM property";
$result = pg_query($connection, $query);

if (!$result) {
    echo "Query execution failed.";
    exit;
}

// Fetch and display data with property detail links
while ($row = pg_fetch_assoc($result)) {
    echo "Property ID: " . $row['id'] . "<br>";
    echo "Location: " . $row['location_city'] . ", " . $row['location_province'] . "<br>";
    echo "Type: " . $row['type'] . "<br>";
    echo "Size Range: " . $row['sizerange_min'] . " - " . $row['sizerange_max'] . "<br>";
    echo "Price Range: " . $row['pricerange_min'] . " - " . $row['pricerange_max'] . "<br>";
    echo "Status: " . $row['status'] . "<br>";

    // Generate a link to the property detail page
    echo '<a href="property_details.php?id=' . $row['id'] . '" target="_blank">View Details</a>';

    echo "<hr>"; // Adding a horizontal line for better readability
}

// Close the database connection
pg_close($connection);
?>
