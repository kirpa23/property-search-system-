<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect users to the login page if they are not logged in
    header("Location: login.php");
    exit();
}

// Fetch and display customer profile details
$username = $_SESSION['username'];

// Perform database query to fetch customer details based on $username

// Display the retrieved information within the HTML structure
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Account Page</title>
    <!-- Add your CSS stylesheets or external stylesheets here -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo $username; ?>!</h1>
        <!-- Display other customer details here based on the fetched information -->
        <!-- Example: Name, email, address, etc. -->
    </div>
</body>
</html>
