<?php
$connection = pg_connect("host=localhost dbname='info 2413' user=postgres password=Kirpa.2003");

if (!$connection) {
    echo "An error occurred while connecting to the database.<br>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = pg_escape_string($connection, $_POST['email']);
    $password = pg_escape_string($connection, $_POST['password']);

    // You should perform proper validation and sanitization of user input
    // before using it in a database query to prevent SQL injection.

    // Check in the 'customer' table
    $customer_query = "SELECT * FROM customer WHERE contactemail = '$username' AND password = '$password'";
    $customer_result = pg_query($connection, $customer_query);

    // Check in the 'realtor' table
    $realtor_query = "SELECT * FROM realtor WHERE email = '$username' AND password = '$password'";
    $realtor_result = pg_query($connection, $realtor_query);

    // Check in the 'administrator' table
    $admin_query = "SELECT * FROM administrator WHERE email = '$username' AND password = '$password'";
    $admin_result = pg_query($connection, $admin_query);

    if ($customer_result && pg_num_rows($customer_result) > 0) {
        // Customer login successful, redirect to homepage.html
        header("Location: index.html");
        exit();
    } elseif ($realtor_result && pg_num_rows($realtor_result) > 0) {
        // Realtor login successful, redirect to realtor_page.php
        header("Location: realtor_page.php");
        exit();
    } elseif ($admin_result && pg_num_rows($admin_result) > 0) {
        // Administrator login successful, redirect to administrator.html
        header("Location: administrator.html");
        exit();
    } else {
        echo "Invalid username or password.<br>";
    }
}
?>
