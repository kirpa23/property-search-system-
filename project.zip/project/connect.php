<?php
$connection = pg_connect("host=localhost dbname='info 2413' user=postgres password=Kirpa.2003");

if (!$connection) {
    echo "An error occurred while connecting to the database.<br>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $contactemail = $_POST['contactemail'];
    $contactphonenumber = $_POST['contactphonenumber'];
    $password = $_POST['password'];
    
    // Using current timestamp for 'timestamp' column
    $timestamp = date('Y-m-d H:i:s'); // Current timestamp in the format YYYY-MM-DD HH:MM:SS

    $query = "INSERT INTO customer (name, contactemail, contactphonenumber, password, timestamp) 
              VALUES ('$name', '$contactemail', '$contactphonenumber', '$password', '$timestamp')";

    $result = pg_query($connection, $query);

    if ($result) {
        echo "Registration successful!<br>";
    } else {
        echo "Error registering user.<br>";
    }
}
?>
