
<<?php
// Database connection
$connection = pg_connect("host=localhost dbname='info2413' user=postgres password=Kirpa.2003");

if (!$connection) {
    echo "An error occurred while connecting to the database.<br>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $realtorId = $_POST['realtorId'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Perform necessary validations and sanitizations on user inputs before using them in queries

    $query = "INSERT INTO realtor (realtor_id, email, password) VALUES ('$realtorId', '$email', '$password')";
    $result = pg_query($connection, $query);

    if ($result) {
        echo "Realtor login ID created successfully.<br>";
    } else {
        echo "Error creating realtor login ID.<br>";
    }
}
?>
