<?php
$connection = pg_connect("host=localhost dbname='info 2413' user=postgres password=Kirpa.2003");

if (!$connection) {
    echo "An error occurred while connecting to the database.<br>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    /
    $query = "SELECT * FROM realtor WHERE email = '$email' AND password = '$password'";
    $result = pg_query($connection, $query);

    if ($result && pg_num_rows($result) > 0) {
        echo "Realtor Login successful!<br>";
    } else {
        echo "Invalid email or password.<br>";
    }
}
?>
